import React, { useState } from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import ProblemStatement from './components/ProblemStatement';
import SolutionOverview from './components/SolutionOverview';
import SocialProof from './components/SocialProof';
import ArtisanFeatures from './components/ArtisanFeatures';
import CustomerMarketplace from './components/CustomerMarketplace';
import CulturalHeritage from './components/CulturalHeritage';
import AuthenticationPages from './components/AuthenticationPages';
import Footer from './components/Footer';

function App() {
  const [currentView, setCurrentView] = useState('home');
  const [userType, setUserType] = useState<'artisan' | 'customer'>('artisan');
  const [isLogin, setIsLogin] = useState(true);

  const handleNavigate = (view: string, type?: 'artisan' | 'customer', login?: boolean) => {
    setCurrentView(view);
    if (type) setUserType(type);
    if (login !== undefined) setIsLogin(login);
  };

  const handleToggleAuth = () => {
    setIsLogin(!isLogin);
  };

  if (currentView === 'auth') {
    return (
      <div className="min-h-screen">
        <AuthenticationPages 
          userType={userType} 
          isLogin={isLogin} 
          onNavigate={handleNavigate}
          onToggleAuth={handleToggleAuth}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <HeroSection onNavigate={handleNavigate} />
        <ProblemStatement />
        <SolutionOverview />
        <SocialProof />
        <ArtisanFeatures />
        <CustomerMarketplace />
        <CulturalHeritage />
      </main>
      <Footer />
    </div>
  );
}

export default App;