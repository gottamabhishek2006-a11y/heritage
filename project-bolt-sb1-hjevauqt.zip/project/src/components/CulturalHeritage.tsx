import React, { useState } from 'react';
import { BookOpen, Map, Users, Clock, ArrowRight } from 'lucide-react';

export default function CulturalHeritage() {
  const [activeRegion, setActiveRegion] = useState('south-asia');

  const regions = {
    'south-asia': {
      name: 'South Asia',
      description: 'Rich traditions spanning thousands of years',
      crafts: [
        { name: 'Block Printing', origin: 'Rajasthan, India', age: '300+ years' },
        { name: 'Pashmina Weaving', origin: 'Kashmir', age: '500+ years' },
        { name: 'Thangka Painting', origin: 'Tibet/Nepal', age: '1000+ years' },
        { name: 'Woodcarving', origin: 'Kerala, India', age: '400+ years' }
      ],
      techniques: [
        'Natural indigo dyeing using fermented indigo leaves',
        'Hand-spinning cashmere from Changthangi goats at 14,000 feet altitude',
        'Mineral pigments ground from precious stones and gold leaf application',
        'Traditional joinery without nails using teak and rosewood'
      ]
    },
    'latin-america': {
      name: 'Latin America',
      description: 'Ancient Mesoamerican and Andean traditions',
      crafts: [
        { name: 'Talavera Pottery', origin: 'Puebla, Mexico', age: '400+ years' },
        { name: 'Backstrap Weaving', origin: 'Guatemala', age: '2000+ years' },
        { name: 'Silver Filigree', origin: 'Oaxaca, Mexico', age: '500+ years' },
        { name: 'Alpaca Textiles', origin: 'Peru', age: '1000+ years' }
      ],
      techniques: [
        'Spanish colonial techniques merged with indigenous Mexican pottery',
        'Pre-Columbian Maya weaving on traditional hip-strap looms',
        'Delicate wire work creating lace-like patterns in precious metals',
        'High-altitude fiber processing from Andean camelids'
      ]
    },
    'africa': {
      name: 'Africa',
      description: 'Diverse traditions across the continent',
      crafts: [
        { name: 'Kente Weaving', origin: 'Ghana', age: '400+ years' },
        { name: 'Zulu Beadwork', origin: 'South Africa', age: '200+ years' },
        { name: 'Ethiopian Textiles', origin: 'Ethiopia', age: '1500+ years' },
        { name: 'Moroccan Zellige', origin: 'Morocco', age: '1000+ years' }
      ],
      techniques: [
        'Complex patterns woven on narrow strip looms, each design carrying meaning',
        'Color-coded beadwork communicating social status and relationships',
        'Hand-spun cotton and traditional plant-based dyes',
        'Hand-cut ceramic mosaic tiles glazed with natural minerals'
      ]
    }
  };

  const heritageTimeline = [
    { era: '3000 BCE', event: 'First evidence of textile weaving in Anatolia' },
    { era: '2000 BCE', event: 'Bronze working spreads across civilizations' },
    { era: '1000 BCE', event: 'Silk Road establishes craft trade networks' },
    { era: '500 CE', event: 'Islamic geometric patterns influence global design' },
    { era: '1500 CE', event: 'Colonial period spreads traditional techniques globally' },
    { era: '2024 CE', event: 'HeritageLink preserves traditions through AI technology' }
  ];

  return (
    <section id="heritage" className="bg-gradient-to-b from-amber-50 to-orange-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-amber-200 text-amber-900 text-sm font-medium mb-4">
            <BookOpen className="h-4 w-4 mr-2" />
            Cultural Heritage Hub
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Preserving Centuries of Human Creativity
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Every craft tells a story of innovation, survival, and cultural identity. 
            Explore the rich heritage behind the products in our marketplace.
          </p>
        </div>

        {/* Interactive Regional Explorer */}
        <div className="bg-white rounded-2xl p-8 mb-12 shadow-sm">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Regional Craft Traditions</h3>
          
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {Object.entries(regions).map(([key, region]) => (
              <button
                key={key}
                onClick={() => setActiveRegion(key)}
                className={`px-6 py-3 rounded-lg font-medium transition-colors ${
                  activeRegion === key
                    ? 'bg-amber-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {region.name}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <h4 className="text-xl font-semibold text-gray-900 mb-3">
                {regions[activeRegion].name} Crafts
              </h4>
              <p className="text-gray-600 mb-6">{regions[activeRegion].description}</p>
              
              <div className="space-y-4">
                {regions[activeRegion].crafts.map((craft, index) => (
                  <div key={index} className="flex items-start p-4 bg-amber-50 rounded-lg">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{craft.name}</div>
                      <div className="text-sm text-gray-600">{craft.origin}</div>
                    </div>
                    <div className="flex items-center text-sm text-amber-700">
                      <Clock className="h-4 w-4 mr-1" />
                      {craft.age}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-xl font-semibold text-gray-900 mb-3">Traditional Techniques</h4>
              <div className="space-y-4">
                {regions[activeRegion].techniques.map((technique, index) => (
                  <div key={index} className="flex items-start p-4 bg-white border border-amber-200 rounded-lg">
                    <ArrowRight className="h-5 w-5 text-amber-600 mr-3 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-700 text-sm leading-relaxed">{technique}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Heritage Timeline */}
        <div className="bg-white rounded-2xl p-8 mb-12 shadow-sm">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            Timeline of Global Craft Heritage
          </h3>
          
          <div className="relative">
            <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gradient-to-b from-amber-600 to-orange-600"></div>
            
            <div className="space-y-6">
              {heritageTimeline.map((item, index) => (
                <div key={index} className="relative flex items-start pl-10">
                  <div className="absolute left-0 w-8 h-8 bg-amber-600 rounded-full flex items-center justify-center">
                    <div className="w-3 h-3 bg-white rounded-full"></div>
                  </div>
                  <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-lg p-4 flex-1">
                    <div className="text-sm font-bold text-amber-800 mb-1">{item.era}</div>
                    <div className="text-gray-700">{item.event}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Educational Resources */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center p-6 bg-white rounded-xl shadow-sm">
            <Map className="h-12 w-12 text-indigo-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Interactive Craft Map</h3>
            <p className="text-gray-600 mb-4">Explore traditional crafts by geographic region and historical period</p>
            <button className="text-indigo-600 hover:text-indigo-800 font-medium">Explore Map →</button>
          </div>
          
          <div className="text-center p-6 bg-white rounded-xl shadow-sm">
            <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Artisan Stories</h3>
            <p className="text-gray-600 mb-4">Meet the masters preserving traditional techniques in the modern world</p>
            <button className="text-green-600 hover:text-green-800 font-medium">Read Stories →</button>
          </div>
          
          <div className="text-center p-6 bg-white rounded-xl shadow-sm">
            <BookOpen className="h-12 w-12 text-purple-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Technique Library</h3>
            <p className="text-gray-600 mb-4">Learn about traditional methods, tools, and materials used by artisans</p>
            <button className="text-purple-600 hover:text-purple-800 font-medium">Browse Library →</button>
          </div>
        </div>
      </div>
    </section>
  );
}