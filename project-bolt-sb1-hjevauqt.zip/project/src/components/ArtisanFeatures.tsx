import React, { useState } from 'react';
import { Mic, Wand2, Globe, BarChart3, Play, Camera } from 'lucide-react';

export default function ArtisanFeatures() {
  const [activeDemo, setActiveDemo] = useState('story');

  const demos = {
    story: {
      title: "AI Story Generator",
      description: "Watch how AI transforms basic product details into compelling cultural narratives",
      input: "Ceramic bowl, blue glaze, made by hand",
      output: "This exquisite ceramic bowl carries the ancient wisdom of Gujarat's pottery traditions, passed down through five generations of master craftspeople. The deep cobalt blue glaze reflects the sacred colors of Lord Krishna's robes, while each curve is shaped by hands that learned their craft from grandmother Devi Patel, a renowned potter who worked with clay from the banks of the Sabarmati River..."
    },
    design: {
      title: "Design Ideation Hub",
      description: "AI analyzes market trends while respecting traditional techniques",
      input: "Traditional paisley pattern, silk scarf",
      output: "Trending Integration: Modern minimalist interpretations of paisley are gaining popularity in European markets. Suggested adaptation: Simplify traditional 40-element paisley to 8-10 key elements, maintain cultural authenticity while appealing to contemporary aesthetics. Color trend: Earthy terracotta and sage green combinations showing 127% increase in customer interest..."
    }
  };

  const features = [
    {
      icon: <Mic className="h-8 w-8 text-blue-600" />,
      title: "Voice-to-Text Interface",
      description: "Speak in your local language to create listings",
      benefit: "No typing skills required"
    },
    {
      icon: <Globe className="h-8 w-8 text-green-600" />,
      title: "Multi-Platform Sync",
      description: "One upload reaches Amazon, Etsy, Instagram & more",
      benefit: "Save 90% of listing time"
    },
    {
      icon: <BarChart3 className="h-8 w-8 text-purple-600" />,
      title: "Cultural Analytics",
      description: "Understand which heritage stories resonate most",
      benefit: "Optimize for cultural impact"
    },
    {
      icon: <Camera className="h-8 w-8 text-amber-600" />,
      title: "Heritage Documentation",
      description: "Record traditional techniques and family stories",
      benefit: "Preserve knowledge for future generations"
    }
  ];

  return (
    <section id="artisans" className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-indigo-100 text-indigo-800 text-sm font-medium mb-4">
            <Wand2 className="h-4 w-4 mr-2" />
            For Traditional Artisans
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            AI Tools Designed for Your Craft
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Technology that understands your heritage and amplifies your story, 
            not replaces your craftsmanship
          </p>
        </div>

        {/* Interactive Demo Section */}
        <div className="bg-gradient-to-br from-gray-50 to-indigo-50 rounded-2xl p-8 mb-12">
          <div className="flex flex-col lg:flex-row gap-8">
            <div className="lg:w-1/3">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">See AI in Action</h3>
              <div className="space-y-3">
                <button
                  onClick={() => setActiveDemo('story')}
                  className={`w-full text-left p-4 rounded-lg transition-colors ${
                    activeDemo === 'story' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center">
                    <Wand2 className="h-5 w-5 mr-3" />
                    <div>
                      <div className="font-medium">Story Generator</div>
                      <div className="text-sm opacity-75">Transform details into narratives</div>
                    </div>
                  </div>
                </button>
                <button
                  onClick={() => setActiveDemo('design')}
                  className={`w-full text-left p-4 rounded-lg transition-colors ${
                    activeDemo === 'design' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center">
                    <BarChart3 className="h-5 w-5 mr-3" />
                    <div>
                      <div className="font-medium">Design Ideation</div>
                      <div className="text-sm opacity-75">Market trends + tradition</div>
                    </div>
                  </div>
                </button>
              </div>
            </div>
            
            <div className="lg:w-2/3 bg-white rounded-xl p-6">
              <div className="flex items-center mb-4">
                <Play className="h-5 w-5 text-green-600 mr-2" />
                <h4 className="text-lg font-semibold text-gray-900">{demos[activeDemo].title}</h4>
              </div>
              <p className="text-gray-600 mb-6">{demos[activeDemo].description}</p>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-500 uppercase tracking-wide">Input</label>
                  <div className="bg-gray-100 rounded-lg p-4 mt-2">
                    <p className="text-gray-800">{demos[activeDemo].input}</p>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-500 uppercase tracking-wide">AI-Generated Output</label>
                  <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg p-4 mt-2 border-l-4 border-indigo-500">
                    <p className="text-gray-800 leading-relaxed">{demos[activeDemo].output}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {features.map((feature, index) => (
            <div key={index} className="text-center p-6 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
              <div className="flex justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600 mb-3 text-sm">{feature.description}</p>
              <div className="inline-flex items-center px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                {feature.benefit}
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors shadow-lg hover:shadow-xl">
            Start Your Digital Journey
          </button>
          <p className="text-gray-500 text-sm mt-3">Free trial • No credit card required • Full cultural support</p>
        </div>
      </div>
    </section>
  );
}