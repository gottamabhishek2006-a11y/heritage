import React, { useState } from 'react';
import { User, Mail, Lock, MapPin, Palette, Award, Globe, Eye, EyeOff } from 'lucide-react';

interface AuthPagesProps {
  userType: 'artisan' | 'customer';
  isLogin: boolean;
  onNavigate: (view: string) => void;
  onToggleAuth: () => void;
}

export default function AuthenticationPages({ userType, isLogin, onNavigate, onToggleAuth }: AuthPagesProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    location: '',
    craft: '',
    experience: '',
    language: 'English'
  });

  const craftTypes = [
    'Pottery & Ceramics',
    'Textiles & Weaving',
    'Woodworking & Carving',
    'Metalwork & Jewelry',
    'Painting & Art',
    'Leatherwork',
    'Glasswork',
    'Stone & Sculpture',
    'Paper & Book Arts',
    'Other Traditional Craft'
  ];

  const experienceLevels = [
    'Less than 1 year',
    '1-3 years',
    '3-5 years',
    '5-10 years',
    '10-20 years',
    'More than 20 years',
    'Generational (Family tradition)'
  ];

  const languages = [
    'English', 'Hindi', 'Spanish', 'French', 'Arabic', 'Portuguese', 
    'Bengali', 'Tamil', 'Gujarati', 'Marathi', 'Other'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-red-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <div className={`p-4 rounded-full ${
              userType === 'artisan' ? 'bg-indigo-100' : 'bg-amber-100'
            }`}>
              {userType === 'artisan' ? (
                <Palette className={`h-8 w-8 ${userType === 'artisan' ? 'text-indigo-600' : 'text-amber-600'}`} />
              ) : (
                <User className={`h-8 w-8 ${userType === 'artisan' ? 'text-indigo-600' : 'text-amber-600'}`} />
              )}
            </div>
          </div>
          <h2 className="text-3xl font-bold text-gray-900">
            {isLogin ? 'Welcome Back' : 'Join HeritageLink'}
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            {userType === 'artisan' 
              ? isLogin 
                ? 'Access your artisan dashboard and AI tools'
                : 'Share your craft with the world through AI storytelling'
              : isLogin
                ? 'Discover authentic heritage crafts'
                : 'Explore stories behind traditional crafts'
            }
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="mt-8 space-y-6">
          <div className="bg-white rounded-xl shadow-sm p-8">
            {!isLogin && (
              <>
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Full Name
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <input
                      id="name"
                      name="name"
                      type="text"
                      required
                      value={formData.name}
                      onChange={handleInputChange}
                      className="appearance-none relative block w-full pl-10 pr-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder="Enter your full name"
                    />
                  </div>
                </div>

                <div className="mt-4">
                  <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-2">
                    Location
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <input
                      id="location"
                      name="location"
                      type="text"
                      required
                      value={formData.location}
                      onChange={handleInputChange}
                      className="appearance-none relative block w-full pl-10 pr-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder={userType === 'artisan' ? 'City, State/Province, Country' : 'Your location'}
                    />
                  </div>
                </div>

                {userType === 'artisan' && (
                  <>
                    <div className="mt-4">
                      <label htmlFor="craft" className="block text-sm font-medium text-gray-700 mb-2">
                        Primary Craft Specialization
                      </label>
                      <div className="relative">
                        <Palette className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                        <select
                          id="craft"
                          name="craft"
                          required
                          value={formData.craft}
                          onChange={handleInputChange}
                          className="appearance-none relative block w-full pl-10 pr-3 py-3 border border-gray-300 text-gray-900 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        >
                          <option value="">Select your craft</option>
                          {craftTypes.map((craft, index) => (
                            <option key={index} value={craft}>{craft}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="mt-4">
                      <label htmlFor="experience" className="block text-sm font-medium text-gray-700 mb-2">
                        Years of Experience
                      </label>
                      <div className="relative">
                        <Award className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                        <select
                          id="experience"
                          name="experience"
                          required
                          value={formData.experience}
                          onChange={handleInputChange}
                          className="appearance-none relative block w-full pl-10 pr-3 py-3 border border-gray-300 text-gray-900 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        >
                          <option value="">Select experience level</option>
                          {experienceLevels.map((level, index) => (
                            <option key={index} value={level}>{level}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </>
                )}

                <div className="mt-4">
                  <label htmlFor="language" className="block text-sm font-medium text-gray-700 mb-2">
                    Preferred Language
                  </label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <select
                      id="language"
                      name="language"
                      value={formData.language}
                      onChange={handleInputChange}
                      className="appearance-none relative block w-full pl-10 pr-3 py-3 border border-gray-300 text-gray-900 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    >
                      {languages.map((language, index) => (
                        <option key={index} value={language}>{language}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </>
            )}

            <div className={!isLogin ? 'mt-4' : ''}>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={handleInputChange}
                  className="appearance-none relative block w-full pl-10 pr-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Enter your email"
                />
              </div>
            </div>

            <div className="mt-4">
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={formData.password}
                  onChange={handleInputChange}
                  className="appearance-none relative block w-full pl-10 pr-10 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 h-5 w-5 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff /> : <Eye />}
                </button>
              </div>
            </div>

            {!isLogin && (
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-start">
                  <input
                    id="terms"
                    type="checkbox"
                    required
                    className="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                  />
                  <label htmlFor="terms" className="ml-3 text-sm text-gray-600">
                    I agree to the{' '}
                    <a href="#" className="text-indigo-600 hover:text-indigo-800">Terms of Service</a>{' '}
                    and{' '}
                    <a href="#" className="text-indigo-600 hover:text-indigo-800">Privacy Policy</a>
                    {userType === 'artisan' && (
                      <span>, and I certify that I am a legitimate artisan committed to preserving traditional crafts.</span>
                    )}
                  </label>
                </div>
              </div>
            )}

            <div className="mt-6">
              <button
                type="submit"
                className={`group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-offset-2 transition-colors ${
                  userType === 'artisan'
                    ? 'bg-indigo-600 hover:bg-indigo-700 focus:ring-indigo-500'
                    : 'bg-amber-600 hover:bg-amber-700 focus:ring-amber-500'
                }`}
              >
                {isLogin ? 'Sign In' : 'Create Account'}
              </button>
            </div>

            <div className="mt-4 text-center">
              <p className="text-sm text-gray-600">
                {isLogin ? "Don't have an account?" : 'Already have an account?'}{' '}
                <button 
                  onClick={onToggleAuth}
                  className={`font-medium hover:underline ${
                  userType === 'artisan' ? 'text-indigo-600' : 'text-amber-600'
                }`}
                >
                  {isLogin ? 'Sign up here' : 'Sign in here'}
                </button>
              </p>
            </div>

            {isLogin && (
              <div className="mt-2 text-center">
                <button 
                  onClick={() => onNavigate('home')}
                  className="text-sm text-gray-500 hover:text-gray-700"
                >
                  Forgot your password?
                </button>
              </div>
            )}

            <div className="mt-4 text-center">
              <button 
                onClick={() => onNavigate('home')}
                className="text-sm text-gray-500 hover:text-gray-700"
              >
                ← Back to Home
              </button>
            </div>
          </div>
        </form>

        {userType === 'artisan' && !isLogin && (
          <div className="bg-indigo-50 rounded-xl p-6 mt-6">
            <h3 className="text-lg font-semibold text-indigo-900 mb-2">
              What happens after registration?
            </h3>
            <ul className="text-sm text-indigo-800 space-y-2">
              <li>• Email verification to ensure authenticity</li>
              <li>• Access to AI story generator for your first product</li>
              <li>• Optional portfolio review for featured placement</li>
              <li>• Cultural heritage documentation assistance</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}