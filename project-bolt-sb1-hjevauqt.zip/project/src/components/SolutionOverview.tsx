import React from 'react';
import { Brain, MessageSquare, Palette, Globe, ArrowRight } from 'lucide-react';

export default function SolutionOverview() {
  const solutions = [
    {
      icon: <Brain className="h-10 w-10 text-indigo-600" />,
      title: "AI Story Generator",
      description: "Transform craft details into compelling stories that showcase cultural heritage and artisan expertise",
      features: ["Multi-language support", "Cultural context preservation", "SEO optimization"]
    },
    {
      icon: <Palette className="h-10 w-10 text-amber-600" />,
      title: "Design Ideation Hub",
      description: "AI-powered trend analysis and design suggestions that respect traditional techniques",
      features: ["Market trend analysis", "Traditional pattern integration", "Customer preference insights"]
    },
    {
      icon: <Globe className="h-10 w-10 text-green-600" />,
      title: "Multi-Platform Integration",
      description: "Seamlessly list products across Amazon, Etsy, Instagram, and more with one upload",
      features: ["Automated formatting", "Platform optimization", "Inventory synchronization"]
    },
    {
      icon: <MessageSquare className="h-10 w-10 text-purple-600" />,
      title: "Voice-to-Text Interface",
      description: "Speak in local languages to create product listings, bridging the digital divide",
      features: ["Regional language support", "Cultural terminology recognition", "Simple voice commands"]
    }
  ];

  return (
    <section className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-green-100 text-green-800 text-sm font-medium mb-4">
            <Brain className="h-4 w-4 mr-2" />
            AI-Powered Solutions
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            How HeritageLink Transforms Artisan Lives
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our AI technology bridges the gap between traditional craftsmanship and modern e-commerce, 
            preserving cultural heritage while empowering artisans economically.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {solutions.map((solution, index) => (
            <div key={index} className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-8 hover:shadow-lg transition-shadow">
              <div className="flex items-start mb-6">
                <div className="flex-shrink-0 mr-4">
                  {solution.icon}
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{solution.title}</h3>
                  <p className="text-gray-600 mb-4">{solution.description}</p>
                  <ul className="space-y-2">
                    {solution.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-sm text-gray-500">
                        <ArrowRight className="h-4 w-4 mr-2 text-green-500" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-indigo-600 to-purple-700 rounded-2xl p-8 md:p-12 text-center text-white">
          <h3 className="text-2xl md:text-3xl font-bold mb-4">
            The HeritageLink Process
          </h3>
          <p className="text-lg mb-8 max-w-3xl mx-auto opacity-90">
            From traditional craft to global marketplace in minutes, not months
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {['Upload Craft Photos', 'AI Generates Stories', 'Multi-Platform Listing', 'Global Sales & Growth'].map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-xl font-bold">{index + 1}</span>
                </div>
                <p className="text-sm font-medium">{step}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}