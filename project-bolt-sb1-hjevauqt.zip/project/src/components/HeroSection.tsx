import React from 'react';
import { ArrowRight, Sparkles, Users, ShoppingBag } from 'lucide-react';

interface HeroSectionProps {
  onNavigate: (view: string, userType: 'artisan' | 'customer', isLogin: boolean) => void;
}

export default function HeroSection({ onNavigate }: HeroSectionProps) {
  return (
    <section className="relative bg-gradient-to-br from-amber-50 to-orange-100 overflow-hidden">
      <div className="absolute inset-0 bg-opacity-10">
        <div className="absolute top-0 left-0 w-full h-full opacity-5">
          <svg width="60" height="60" viewBox="0 0 60 60" className="absolute top-10 left-10">
            <polygon points="30,5 40,25 20,25" fill="currentColor" className="text-amber-800"/>
          </svg>
          <svg width="40" height="40" viewBox="0 0 40 40" className="absolute top-20 right-20">
            <circle cx="20" cy="20" r="15" fill="none" stroke="currentColor" strokeWidth="2" className="text-orange-700"/>
          </svg>
          <svg width="50" height="50" viewBox="0 0 50 50" className="absolute bottom-20 left-1/4">
            <rect x="10" y="10" width="30" height="30" fill="currentColor" className="text-amber-700" transform="rotate(45 25 25)"/>
          </svg>
        </div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20">
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-amber-200 text-amber-900 text-sm font-medium">
              <Sparkles className="h-4 w-4 mr-2" />
              AI-Powered Heritage Marketplace
            </div>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Connecting Culture, 
            <span className="text-amber-600"> Artisans,</span> and 
            <span className="text-indigo-700"> Consumers</span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
            Bridge traditional craftsmanship with modern e-commerce through AI. 
            Help local artisans tell their stories, reach global markets, and preserve cultural heritage 
            for future generations.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <button 
              onClick={() => onNavigate('auth', 'artisan', true)}
              className="group bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-all transform hover:scale-105 flex items-center shadow-lg hover:shadow-xl"
            >
              <Users className="h-5 w-5 mr-2" />
              Login as Artisan
              <ArrowRight className="h-5 w-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </button>
            
            <button 
              onClick={() => onNavigate('auth', 'customer', true)}
              className="group bg-amber-600 hover:bg-amber-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-all transform hover:scale-105 flex items-center shadow-lg hover:shadow-xl"
            >
              <ShoppingBag className="h-5 w-5 mr-2" />
              Login as Customer
              <ArrowRight className="h-5 w-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button 
              onClick={() => onNavigate('auth', 'artisan', false)}
              className="text-indigo-600 hover:text-indigo-800 px-6 py-2 border-2 border-indigo-600 hover:bg-indigo-50 rounded-lg font-medium transition-colors"
            >
              Register as Artisan
            </button>
            <button 
              onClick={() => onNavigate('auth', 'customer', false)}
              className="text-amber-600 hover:text-amber-800 px-6 py-2 border-2 border-amber-600 hover:bg-amber-50 rounded-lg font-medium transition-colors"
            >
              Shop Heritage Products
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}