import React, { useState } from 'react';
import { Menu, X, Heart, Globe, User } from 'lucide-react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b-2 border-amber-100">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Heart className="h-8 w-8 text-amber-600 mr-2" />
            <span className="text-xl font-bold text-indigo-900">HeritageLink</span>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <a href="#heritage" className="text-gray-700 hover:text-indigo-900 px-3 py-2 rounded-md text-sm font-medium transition-colors">
                Heritage Stories
              </a>
              <a href="#artisans" className="text-gray-700 hover:text-indigo-900 px-3 py-2 rounded-md text-sm font-medium transition-colors">
                For Artisans
              </a>
              <a href="#marketplace" className="text-gray-700 hover:text-indigo-900 px-3 py-2 rounded-md text-sm font-medium transition-colors">
                Marketplace
              </a>
              <a href="#about" className="text-gray-700 hover:text-indigo-900 px-3 py-2 rounded-md text-sm font-medium transition-colors">
                About
              </a>
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-3">
            <Globe className="h-5 w-5 text-gray-500" />
            <select className="text-sm border-none bg-transparent text-gray-700 focus:ring-0">
              <option>English</option>
              <option>Hindi</option>
              <option>Tamil</option>
            </select>
          </div>

          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="bg-gray-100 inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-gray-50 rounded-lg mt-2">
              <a href="#heritage" className="text-gray-700 hover:text-indigo-900 block px-3 py-2 rounded-md text-base font-medium">
                Heritage Stories
              </a>
              <a href="#artisans" className="text-gray-700 hover:text-indigo-900 block px-3 py-2 rounded-md text-base font-medium">
                For Artisans
              </a>
              <a href="#marketplace" className="text-gray-700 hover:text-indigo-900 block px-3 py-2 rounded-md text-base font-medium">
                Marketplace
              </a>
              <a href="#about" className="text-gray-700 hover:text-indigo-900 block px-3 py-2 rounded-md text-base font-medium">
                About
              </a>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}