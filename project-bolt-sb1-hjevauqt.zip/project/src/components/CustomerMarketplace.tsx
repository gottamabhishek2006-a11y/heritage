import React from 'react';
import { Heart, Shield, MapPin, Clock, Star } from 'lucide-react';

export default function CustomerMarketplace() {
  const products = [
    {
      id: 1,
      name: "Hand-carved Sandalwood Elephant",
      artisan: "Ramesh Kumar",
      location: "Mysore, Karnataka",
      price: "$89",
      story: "Carved from sacred sandalwood using 300-year-old family techniques passed down through 8 generations...",
      image: "https://images.pexels.com/photos/7504845/pexels-photo-7504845.jpeg?auto=compress&cs=tinysrgb&w=400",
      heritage: "Mysore Woodcraft Tradition",
      rating: 4.9,
      reviews: 127,
      timeToMake: "3 weeks",
      authenticity: "Verified Heritage Craft"
    },
    {
      id: 2,
      name: "Indigo Block-printed Cotton Scarf",
      artisan: "Priya Sharma",
      location: "Jaipur, Rajasthan",
      price: "$34",
      story: "Block-printed using natural indigo dye and traditional stamps carved by my grandfather in 1952...",
      image: "https://images.pexels.com/photos/7319070/pexels-photo-7319070.jpeg?auto=compress&cs=tinysrgb&w=400",
      heritage: "Rajasthani Block Printing",
      rating: 4.8,
      reviews: 89,
      timeToMake: "5 days",
      authenticity: "Certified Traditional Method"
    },
    {
      id: 3,
      name: "Ceramic Tea Set with Floral Motifs",
      artisan: "Maria Gonzalez",
      location: "Puebla, Mexico",
      price: "$156",
      story: "Each piece is hand-painted with traditional Talavera patterns that tell the story of our ancestors...",
      image: "https://images.pexels.com/photos/6471154/pexels-photo-6471154.jpeg?auto=compress&cs=tinysrgb&w=400",
      heritage: "Talavera Pottery Tradition",
      rating: 4.9,
      reviews: 203,
      timeToMake: "2 weeks",
      authenticity: "UNESCO Protected Craft"
    }
  ];

  const filters = [
    "All Heritage Crafts",
    "Textiles & Fabric",
    "Pottery & Ceramics",
    "Woodwork & Carving",
    "Jewelry & Accessories",
    "Home Decor",
    "Religious & Spiritual"
  ];

  const regions = [
    "All Regions",
    "South Asia",
    "Southeast Asia",
    "Latin America",
    "Africa",
    "Middle East",
    "Europe"
  ];

  return (
    <section id="marketplace" className="bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Heritage Marketplace
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover authentic handcrafted treasures with rich cultural stories. 
            Every purchase preserves tradition and supports artisan families.
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="text-sm font-medium text-gray-700 mr-4 py-2">Filter by Craft:</span>
            {filters.slice(0, 4).map((filter, index) => (
              <button
                key={index}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  index === 0 
                    ? 'bg-amber-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
          
          <div className="flex flex-wrap gap-2">
            <span className="text-sm font-medium text-gray-700 mr-4 py-2">Filter by Region:</span>
            {regions.slice(0, 4).map((region, index) => (
              <button
                key={index}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  index === 0 
                    ? 'bg-indigo-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
                }`}
              >
                {region}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <div key={product.id} className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow">
              <div className="relative">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-64 object-cover"
                />
                <button className="absolute top-4 right-4 p-2 bg-white bg-opacity-90 rounded-full hover:bg-opacity-100 transition-colors">
                  <Heart className="h-5 w-5 text-gray-600 hover:text-red-500" />
                </button>
                <div className="absolute bottom-4 left-4">
                  <div className="inline-flex items-center px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                    <Shield className="h-3 w-3 mr-1" />
                    {product.authenticity}
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-lg font-semibold text-gray-900">{product.name}</h3>
                  <span className="text-xl font-bold text-amber-600">{product.price}</span>
                </div>
                
                <div className="flex items-center text-sm text-gray-600 mb-3">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span className="font-medium">{product.artisan}</span>
                  <span className="mx-2">•</span>
                  <span>{product.location}</span>
                </div>
                
                <div className="bg-amber-50 rounded-lg p-3 mb-4">
                  <h4 className="text-sm font-medium text-amber-900 mb-1">{product.heritage}</h4>
                  <p className="text-sm text-amber-800 leading-relaxed">{product.story}</p>
                </div>
                
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 fill-current mr-1" />
                    <span className="font-medium text-gray-900">{product.rating}</span>
                    <span className="mx-1">•</span>
                    <span>{product.reviews} reviews</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>{product.timeToMake}</span>
                  </div>
                </div>
                
                <button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-4 rounded-lg font-medium transition-colors">
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-3 rounded-lg font-medium transition-colors mr-4">
            View All Products
          </button>
          <button className="border-2 border-amber-600 text-amber-600 hover:bg-amber-50 px-8 py-3 rounded-lg font-medium transition-colors">
            Learn About Heritage Crafts
          </button>
        </div>
      </div>
    </section>
  );
}