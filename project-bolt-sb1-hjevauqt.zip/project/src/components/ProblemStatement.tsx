import React from 'react';
import { TrendingDown, Wifi, Globe, AlertCircle } from 'lucide-react';

export default function ProblemStatement() {
  const challenges = [
    {
      icon: <TrendingDown className="h-8 w-8 text-red-600" />,
      title: "Limited Market Reach",
      description: "87% of traditional artisans struggle to reach customers beyond their local community",
      stat: "87%"
    },
    {
      icon: <Wifi className="h-8 w-8 text-red-600" />,
      title: "Digital Exclusion",
      description: "Most artisans lack the digital skills and tools needed for online commerce",
      stat: "73%"
    },
    {
      icon: <Globe className="h-8 w-8 text-red-600" />,
      title: "Lost Cultural Context",
      description: "Rich heritage stories behind crafts are often lost in mass market platforms",
      stat: "92%"
    },
    {
      icon: <AlertCircle className="h-8 w-8 text-red-600" />,
      title: "Unfair Competition",
      description: "Machine-made products often overshadow authentic handcrafted items",
      stat: "64%"
    }
  ];

  return (
    <section className="bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            The Challenge Facing Traditional Artisans
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Despite creating beautiful, authentic products with rich cultural heritage, 
            traditional artisans face significant barriers in today's digital economy.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {challenges.map((challenge, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-4">
                {challenge.icon}
                <span className="text-2xl font-bold text-red-600">{challenge.stat}</span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{challenge.title}</h3>
              <p className="text-gray-600 text-sm">{challenge.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-red-50 to-orange-50 rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            Traditional Crafts at Risk
          </h3>
          <p className="text-lg text-gray-700 mb-6 max-w-2xl mx-auto">
            Without digital inclusion, we risk losing generations of cultural knowledge and 
            leaving skilled artisans economically marginalized in an increasingly connected world.
          </p>
          <div className="inline-flex items-center px-4 py-2 bg-red-100 rounded-full">
            <AlertCircle className="h-5 w-5 text-red-600 mr-2" />
            <span className="text-red-800 font-medium">Cultural Heritage in Decline</span>
          </div>
        </div>
      </div>
    </section>
  );
}