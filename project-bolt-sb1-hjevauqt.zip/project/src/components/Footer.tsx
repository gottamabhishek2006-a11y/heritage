import React from 'react';
import { Heart, Mail, Phone, MapPin, Facebook, Instagram, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1">
            <div className="flex items-center mb-4">
              <Heart className="h-8 w-8 text-amber-500 mr-2" />
              <span className="text-xl font-bold">HeritageLink</span>
            </div>
            <p className="text-gray-400 mb-6 text-sm leading-relaxed">
              Connecting culture, artisans, and consumers through AI technology. 
              Preserving heritage while building global markets.
            </p>
            <div className="flex space-x-4">
              <Facebook className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
              <Instagram className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
              <Twitter className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
            </div>
          </div>

          {/* For Artisans */}
          <div>
            <h3 className="text-lg font-semibold mb-4">For Artisans</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors">AI Story Generator</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Design Ideation Hub</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Multi-Platform Sync</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Voice-to-Text Tools</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Heritage Documentation</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Artisan Registration</a></li>
            </ul>
          </div>

          {/* For Customers */}
          <div>
            <h3 className="text-lg font-semibold mb-4">For Customers</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors">Heritage Marketplace</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Authentic Products</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Artisan Stories</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Cultural Education</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Gift Collections</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Customer Support</a></li>
            </ul>
          </div>

          {/* Contact & Support */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact & Support</h3>
            <div className="space-y-3 text-sm text-gray-400">
              <div className="flex items-center">
                <Mail className="h-4 w-4 mr-2" />
                <span>hello@heritagelink.com</span>
              </div>
              <div className="flex items-center">
                <Phone className="h-4 w-4 mr-2" />
                <span>+1-800-HERITAGE</span>
              </div>
              <div className="flex items-start">
                <MapPin className="h-4 w-4 mr-2 mt-0.5" />
                <span>Global platform<br />Supporting artisans worldwide</span>
              </div>
            </div>
            
            <div className="mt-6">
              <h4 className="font-medium text-white mb-2">Newsletter</h4>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email"
                  className="flex-1 px-3 py-2 bg-gray-800 text-white text-sm rounded-l-lg border border-gray-700 focus:outline-none focus:border-amber-500"
                />
                <button className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-sm rounded-r-lg transition-colors">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-sm text-gray-400 mb-4 md:mb-0">
              © 2024 HeritageLink. All rights reserved. Preserving culture through technology.
            </div>
            <div className="flex space-x-6 text-sm text-gray-400">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}