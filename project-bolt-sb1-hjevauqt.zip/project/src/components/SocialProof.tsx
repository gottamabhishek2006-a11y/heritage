import React from 'react';
import { Star, Quote, TrendingUp, Users, Award } from 'lucide-react';

export default function SocialProof() {
  const testimonials = [
    {
      name: "Meera Patel",
      craft: "Traditional Pottery",
      location: "Gujarat, India",
      quote: "HeritageLink helped me reach customers in 12 countries. My pottery now tells the story of my grandmother's techniques.",
      rating: 5,
      impact: "300% increase in sales"
    },
    {
      name: "Carlos Rodriguez",
      craft: "Hand-woven Textiles",
      location: "Oaxaca, Mexico",
      quote: "The AI storytelling feature captured the spiritual meaning behind my patterns. Customers now understand the cultural significance.",
      rating: 5,
      impact: "Featured on international platforms"
    },
    {
      name: "Fatima Al-Zahra",
      craft: "Intricate Metalwork",
      location: "Fez, Morocco",
      quote: "I was afraid of technology, but the voice interface made it so easy. Now I manage my global sales while preserving my traditional methods.",
      rating: 5,
      impact: "Expanded to 3 new markets"
    }
  ];

  const stats = [
    { icon: <Users className="h-8 w-8 text-indigo-600" />, value: "2,500+", label: "Active Artisans" },
    { icon: <TrendingUp className="h-8 w-8 text-green-600" />, value: "180%", label: "Average Sales Increase" },
    { icon: <Award className="h-8 w-8 text-amber-600" />, value: "45", label: "Countries Reached" },
    { icon: <Star className="h-8 w-8 text-purple-600" />, value: "4.9/5", label: "Artisan Satisfaction" }
  ];

  return (
    <section className="bg-gradient-to-b from-gray-50 to-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Transforming Lives Across Cultures
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Real stories from artisans who've preserved their heritage while building global businesses
          </p>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="flex justify-center mb-3">
                {stat.icon}
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
              <div className="text-sm text-gray-600">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-xl p-8 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start mb-4">
                <Quote className="h-6 w-6 text-amber-500 mr-2 flex-shrink-0 mt-1" />
                <p className="text-gray-700 italic leading-relaxed">{testimonial.quote}</p>
              </div>
              
              <div className="flex items-center mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                ))}
              </div>
              
              <div className="border-t pt-4">
                <div className="font-semibold text-gray-900">{testimonial.name}</div>
                <div className="text-sm text-gray-600">{testimonial.craft}</div>
                <div className="text-sm text-gray-500 mb-2">{testimonial.location}</div>
                <div className="inline-flex items-center px-3 py-1 rounded-full bg-green-100 text-green-800 text-sm font-medium">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  {testimonial.impact}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="inline-flex items-center px-6 py-3 bg-indigo-100 rounded-full">
            <Award className="h-5 w-5 text-indigo-600 mr-2" />
            <span className="text-indigo-800 font-medium">UNESCO Heritage Preservation Partner</span>
          </div>
        </div>
      </div>
    </section>
  );
}